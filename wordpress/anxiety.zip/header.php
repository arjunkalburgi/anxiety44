<!DOCTYPE html>
<html>
<head>
	<title>anxiety44</title>
	
	<link rel="stylesheet" type="text/css" href="style.css">


	<script src="https://unpkg.com/scrollreveal/dist/scrollreveal.min.js"></script>

	<!-- ScrollMagic -->
	<script src="http://scrollmagic.io/js/lib/greensock/TweenMax.min.js"></script>
	<script src="http://scrollmagic.io/scrollmagic/uncompressed/ScrollMagic.js"></script>
	<script src="http://scrollmagic.io/scrollmagic/uncompressed/plugins/animation.gsap.js"></script>
	<script src="http://scrollmagic.io/scrollmagic/uncompressed/plugins/debug.addIndicators.js"></script>

	<script src="http://scrollmagic.io/js/lib/jquery.min.js"></script>



</head>
<body>
	<nav>
		<div class="nav-wrapper">
			<a href="#" class="brand-logo">A44</a>
			<ul id="nav-mobile" class="right hide-on-med-and-down">
				<li><a href="sass.html">HOME</a></li>
				<li><a href="badges.html">CONTACT</a></li>
				<li><a href="collapsible.html">IG</a></li>
			</ul>
		</div>
	</nav>